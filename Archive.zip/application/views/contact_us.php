<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
	<section id="detail_candidate_area" style="
		padding: 0px 0px;
		background: #fff;">
		<div class="container">
			<div class="row">
				<div class="col-12 mx-auto">
                <div style="padding: 35px 40px;">
                    <p style="padding-bottom: 25px;text-align:center;font-size:22px;">
                        <b>CONTACTAR</b>
                    </p>              
                    <p style="text-align:center;line-height: 1.5;font-size:18px">                
                    Enviar preguntas, comentarios 
                    o sugerencias al email:<br><br>
                    <b><a href="mailto:contacto@votosimple.com">contacto@votosimple.com</a></b><br><br>
                    </p> 
                </div>             
			</div>
		</div>
	</section>
