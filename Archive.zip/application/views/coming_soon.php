<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
	<section id="detail_candidate_area" style="
		padding: 0px 0px;
		background: #fff;">
		<div class="container">
			<div class="row">
				<div class="col-12 mx-auto">
                <div style="padding: 30px 50px;">
                    <p style="padding-bottom: 25px;text-align:center;font-size:22px;">
                        <b>PRONTO</b>
                    </p>              
                    <p style="text-align:center;line-height: 1.5;font-size:18px">                
                    Nuevas páginas con los candidatos a Gobernadores (G), 
                    Alcaldes (A) y Concejales (Cj).
                    </p> 
                    <br><br><br><br><br>
                    <div class="text-center mb-4">
						<a style="margin-top: 10px;" href="javascript:history.back()" class="btn btn-swal2-cancel">VOLVER AL SITIO</a>
					</div>
                </div>             
			</div>
		</div>
	</section>
